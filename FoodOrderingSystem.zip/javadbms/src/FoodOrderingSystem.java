import java.sql.*;
import java.util.*;

import java.io.*;

public class FoodOrderingSystem {
    private Connection connection;
    private Stack<String> actionStack;
    private LinkedList<String> actionHistory;
    static Scanner scanner = new Scanner(System.in);

    public FoodOrderingSystem(Connection connection) {
        this.connection = connection;
        this.actionStack = new Stack<>();
        this.actionHistory = new LinkedList<>();
    }

    public void addFoodItem(String name, String category, double price, boolean available) throws SQLException {
        String query = "INSERT INTO food_items (Name, Category, Price, Available) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, name);
            stmt.setString(2, category);
            stmt.setDouble(3, price);
            stmt.setBoolean(4, available);
            stmt.executeUpdate();

            String action = "Added food item: " + name;
            actionStack.push(action);
            actionHistory.add(action);
            System.out.println(action);
        }
    }

    public void retrieveFoodItem(int id) throws SQLException {
        String query = "SELECT * FROM food_items WHERE Food_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("ID: " + rs.getInt(1));
                System.out.println("Name: " + rs.getString("Name"));
                System.out.println("Category: " + rs.getString("Category"));
                System.out.println("Price: " + rs.getDouble("Price"));
                System.out.println("Available: " + rs.getBoolean("Available"));

                String action = "Retrieved food item with ID: " + id;
                actionStack.push(action);
                actionHistory.add(action);
            } else {
                System.out.println("Food item not found.");
            }
        }
    }

    public void updateFoodItem() throws SQLException {
        System.out.print("Enter food item ID to update: ");
        int updateId = scanner.nextInt();
        String sql = "select * from food_items where Food_id=?";
        PreparedStatement st = connection.prepareStatement(sql);
        st.setInt(1, updateId);
        ResultSet rs = st.executeQuery();
        if (!rs.isBeforeFirst()) {
            System.out.println("item id not available!");
            return;
        }

        String query = "UPDATE food_items SET Name = ?, Category = ?, Price = ?, Available = ? WHERE Food_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            scanner.nextLine(); // Consume newline

            System.out.print("Enter new name: ");
            String newName = scanner.nextLine();
            System.out.print("Enter new category: ");
            String newCategory = scanner.nextLine();
            System.out.print("Enter new price: ");
            double newPrice = scanner.nextDouble();
            System.out.print("Is it available (true/false): ");
            boolean newAvailable = scanner.nextBoolean();
            stmt.setString(1, newName);
            stmt.setString(2, newCategory);
            stmt.setDouble(3, newPrice);
            stmt.setBoolean(4, newAvailable);
            stmt.setInt(5, updateId);
            stmt.executeUpdate();

            String action = "Updated food item with ID: " + updateId;
            actionStack.push(action);
            actionHistory.add(action);
            System.out.println(action);
        }
    }

    public void deleteFoodItem() throws SQLException {
        System.out.print("Enter food item ID to update: ");
        int updateId = scanner.nextInt();
        String sql = "select * from food_items where Food_id=?";
        PreparedStatement st = connection.prepareStatement(sql);
        st.setInt(1, updateId);
        ResultSet rs = st.executeQuery();
        if (!rs.isBeforeFirst()) {
            System.out.println("item id not available!");
            return;
        }
        String query = "DELETE FROM food_items WHERE Food_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, updateId);
            stmt.executeUpdate();

            String action = "Deleted food item with ID: " + updateId;
            actionStack.push(action);
            actionHistory.add(action);
            System.out.println(action);
        }
    }

    public void placeOrder() throws Exception {
        String sql = "select * from cart";
        PreparedStatement pst1 = connection.prepareStatement(sql);
        ResultSet rs1 = pst1.executeQuery();
        if (!rs1.isBeforeFirst()) {
            System.out.println("cart is empty!");
            return;
        }
        String query = "INSERT INTO orders (Food_id, Quantity, Status,Address,Amount) VALUES (?, ?, 'pending',?,?)";
        System.out.println("enter address:");
        String address = scanner.nextLine();
        PreparedStatement pst = connection.prepareStatement("select Food_id,sum(Item_quantity) from cart");
        ResultSet rs = pst.executeQuery();
        rs.next();
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, rs.getInt(1));
            stmt.setInt(2, rs.getInt(2));
            stmt.setString(3, address);
            stmt.setDouble(4, takeOrder(connection));
            stmt.executeUpdate();

        }
        System.out.println("enter 1 for upi payment, 2 for cash on delivery : ");
        int p_choice = scanner.nextInt();
        String p_Method = "";
        String upi = "";
        switch (p_choice) {
            case 1: {
                System.out.println("enter your upi : ");
                int i = 0;
                do {
                    upi = scanner.next();
                    p_Method = "upi";
                    if (upi.contains("@")) {
                        String[] check = upi.split("@");
                        if (check.length == 1) {
                            System.out.println("enter valid upi id!");
                        } else {
                            switch (check[1]) {
                                case "oksbi":
                                case "okaxis":
                                case "icici":
                                case "okicici":
                                case "okhdfcbank":
                                case "axisb":
                                case "sbi":
                                case "fam":
                                case "paytm": {
                                    System.out.println("thank you for ordering!");
                                    i = 1;
                                    break;
                                }
                                default: {
                                    System.out.println("enter valid upi id!");
                                }
                            }
                        }
                    } else {
                        System.out.println("enter valid upi id!");
                    }
                } while (i == 0);

                break;
            }
            case 2: {
                p_Method = "cash on delivery";
                break;
            }
            default: {
                System.out.println("enter valid choice !");
            }
        }
        Statement st = connection.createStatement();
        st.executeQuery("select Order_id from orders");
        while (!rs.isLast()) {
            rs.next();
        }
        Payment p = new Payment();
        p.payment_details(connection, rs.getInt(1), p_Method, takeOrder(connection));
        String action = "Placed order for food item ID: " + rs.getInt(1) + " with quantity: " + rs.getInt(2);
        actionStack.push(action);
        actionHistory.add(action);
        System.out.println(action);
        FileHandling(rs.getInt(1));
    }

    public void FileHandling(int id) throws Exception {
        FileWriter fw = new FileWriter("D://Order_" + id + ".txt");
        Statement st = connection.createStatement();
        ResultSet rs = st.executeQuery("select * from orders where Order_id=" + id);
        rs.next();
        fw.write("order id : " + id);
        fw.write("food id : " + rs.getInt(2));
        fw.write("quantity : " + rs.getInt(3));
        fw.write("amount : " + rs.getDouble(6));
        fw.close();
        System.out.println("details of order id " + id + " is stored in Order_" + id + ".txt file in D drive");
    }

    public double takeOrder(Connection connection) throws Exception {
        String sql = "select sum(Total_price) from cart;";
        Statement st = connection.createStatement();
        ResultSet rs = st.executeQuery(sql);
        if (rs.next()) {
            double price = rs.getDouble(1);
            return price;
        } else {
            return 0.0;
        }
    }

    public void updateOrderStatus() throws SQLException {
        System.out.print("Enter order ID to update status: ");
        int updateId = scanner.nextInt();
        String sql = "select * from orders where Order_id=?";
        PreparedStatement st = connection.prepareStatement(sql);
        st.setInt(1, updateId);
        ResultSet rs = st.executeQuery();
        if (!rs.isBeforeFirst()) {
            System.out.println("order id not available!");
            return;
        }
        String query = "UPDATE orders SET Status = ? WHERE Order_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            System.out.println("enter status:");
            scanner.nextLine();
            String status = scanner.nextLine();
            stmt.setString(1, status);
            stmt.setInt(2, updateId);
            stmt.executeUpdate();

            String action = "Updated order ID: " + updateId + " to status: " + status;
            actionStack.push(action);
            actionHistory.add(action);
            System.out.println(action);
        }
    }

    public void undoLastAction() {
        if (!actionStack.isEmpty()) {
            String lastAction = actionStack.pop();
            System.out.println("Undoing last action: " + lastAction);
        } else {
            System.out.println("No actions to undo.");
        }
    }

    public void displayActionHistory() {
        if (actionHistory.isEmpty()) {
            System.out.println("Action history is empty!");
        } else {
            System.out.println("Action History:");
            for (String action : actionHistory) {
                System.out.println(action);
            }
        }
    }

    public void displayDatabaseMetadata() throws SQLException {
        DatabaseMetaData metaData = connection.getMetaData();
        System.out.println("Database Product Name: " + metaData.getDatabaseProductName());
        System.out.println("Database Product Version: " + metaData.getDatabaseProductVersion());
        System.out.println("Driver Name: " + metaData.getDriverName());
        System.out.println("Driver Version: " + metaData.getDriverVersion());
    }

    public void displayResultSetMetadata() throws SQLException {
        String query = "SELECT * FROM food_items LIMIT 1";
        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            ResultSetMetaData rsMetaData = rs.getMetaData();
            int columnCount = rsMetaData.getColumnCount();
            System.out.println("Table Name: " + rsMetaData.getTableName(1));
            System.out.println("Column Count: " + columnCount);
            for (int i = 1; i <= columnCount; i++) {
                System.out.println("Column " + i + ": " + rsMetaData.getColumnName(i));
            }
        }
    }

    public void exit() throws SQLException {
        if (connection != null && !connection.isClosed()) {
            connection.close();
            System.out.println("Database connection closed.");
        }
    }

    // Cart functionalities
    public void addItemToCart(int id, int quantity, double price, Connection connection) throws SQLException {
        String query = "INSERT INTO cart (Food_id, Item_quantity, Item_price, Total_price) VALUES (?, ?, ?, ?)";
        try {
            PreparedStatement stmt = connection.prepareStatement(query);
            Double tp = price * quantity;
            stmt.setInt(1, id);
            stmt.setInt(2, quantity);
            stmt.setDouble(3, price);
            stmt.setDouble(4, tp);
            stmt.executeUpdate();
            System.out.println("item id " + id + " is inserted with quantity " + quantity);
        } catch (SQLIntegrityConstraintViolationException e) {
            PreparedStatement stmt = connection
                    .prepareStatement("update cart set Item_quantity=?,Total_price=? where Food_id=?");
            Double tp = price * quantity;
            stmt.setInt(1, quantity);
            stmt.setDouble(2, tp);
            stmt.setInt(3, id);
            System.out.println(quantity + " Item quantity added for item id " + id);
        }

    }

    public void removeItemFromCart() throws SQLException {
        System.out.print("Enter food item ID to delete: ");
        int updateId = scanner.nextInt();
        String sql = "select * from cart where Food_id=?";
        PreparedStatement st = connection.prepareStatement(sql);
        st.setInt(1, updateId);
        ResultSet rs = st.executeQuery();
        if (!rs.isBeforeFirst()) {
            System.out.println("item id not available!");
            return;
        }
        rs.next();
        if (rs.getInt("Item_quantity") == 1) {
            String query = "DELETE FROM cart WHERE Food_id = ?";
            try (PreparedStatement stmt = connection.prepareStatement(query)) {
                stmt.setInt(1, updateId);
                stmt.executeUpdate();
                System.out.println("Item removed from cart: ID = " + updateId);
            }
        } else {
            PreparedStatement pst = connection.prepareStatement("update cart set Item_quantity=? where Food_id=?");
            pst.setInt(1, rs.getInt("Item_quantity") - 1);
            pst.setInt(2, updateId);
            pst.executeUpdate();
            System.out.println(
                    "Item quantity redused " + rs.getInt("Item_quantity") + " to " + (rs.getInt("Item_quantity") - 1));
        }
    }

    public void viewCart() throws SQLException {
        String query = "SELECT * FROM cart";
        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            if (!rs.isBeforeFirst()) {
                System.out.println("Your cart is empty.");
            } else {
                while (rs.next()) {
                    System.out.println();
                    System.out.println("Item ID: " + rs.getInt(1));
                    System.out.println("Quantity: " + rs.getInt(2));
                    System.out.println("Price: " + rs.getDouble(3));
                    System.out.println("Total Price: " + rs.getDouble(4));
                    System.out.println("-------------------");
                }
            }
        }
    }

    public void emptyCart() throws SQLException {
        String query = "TRUNCATE TABLE cart";
        try (Statement stmt = connection.createStatement()) {
            stmt.executeUpdate(query);
            System.out.println("Your cart is now empty.");
        }
    }

    public static void main(String[] args) throws Exception {
        String url = "jdbc:mysql://localhost:3306/restaurant_db";
        String user = "root";
        String password = "";
        try (Connection connection = DriverManager.getConnection(url, user, password)) {
            FoodOrderingSystem system = new FoodOrderingSystem(connection);
            Scanner scanner = new Scanner(System.in);
            boolean running = true;
            Statement st=connection.createStatement();
            st.execute("truncate table cart");
            while (running) {
                System.out.println("\nLogin as:");
                System.out.println("1. Admin");
                System.out.println("2. User");
                System.out.println("3. Exit");
                System.out.print("Select an option: ");

                int roleChoice = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                switch (roleChoice) {
                    case 1:
                        // Admin operations
                        boolean adminRunning = true;
                        while (adminRunning) {
                            System.out.println("\nAdmin :");
                            System.out.println("1. Add Food Item");
                            System.out.println("2. Retrieve Food Item");
                            System.out.println("3. Update Food Item");
                            System.out.println("4. Delete Food Item");
                            System.out.println("5. Update Order Status");
                            System.out.println("6. Display Action History");
                            System.out.println("7. Display Database Metadata");
                            System.out.println("8. Display ResultSet Metadata");
                            System.out.println("9. Undo Last Action");
                            System.out.println("10. Logout");
                            System.out.print("Select an option: ");

                            int adminChoice = scanner.nextInt();
                            scanner.nextLine(); // Consume newline

                            switch (adminChoice) {
                                case 1:
                                    System.out.print("Enter name: ");
                                    String name = scanner.nextLine();
                                    System.out.print("Enter category: ");
                                    String category = scanner.nextLine();
                                    System.out.print("Enter price: ");
                                    double price = scanner.nextDouble();
                                    System.out.print("Is it available (true/false): ");
                                    boolean available = scanner.nextBoolean();
                                    system.addFoodItem(name, category, price, available);
                                    break;

                                case 2:
                                    System.out.print("Enter food item ID to retrieve: ");
                                    int retrieveId = scanner.nextInt();
                                    system.retrieveFoodItem(retrieveId);
                                    break;

                                case 3:

                                    system.updateFoodItem();
                                    break;

                                case 4:
                                    system.deleteFoodItem();
                                    break;

                                case 5:
                                    system.updateOrderStatus();
                                    break;

                                case 6:
                                    system.displayActionHistory();
                                    break;

                                case 7:
                                    system.displayDatabaseMetadata();
                                    break;

                                case 8:
                                    system.displayResultSetMetadata();
                                    break;

                                case 9:
                                    system.undoLastAction();
                                    break;

                                case 10:
                                    adminRunning = false;
                                    System.exit(0);
                                    break;

                                default:
                                    System.out.println("Invalid option. Please try again.");
                            }
                        }
                        break;

                    case 2:
                        // User operations
                        boolean userRunning = true;
                        while (userRunning) {
                            System.out.println("\nUser Menu:");
                            System.out.println("1. Add Item to Cart");
                            System.out.println("2. View Cart");
                            System.out.println("3. Remove Item from Cart");
                            System.out.println("4. Empty Cart");
                            System.out.println("5. Place Order");
                            System.out.println("6. see menu");
                            System.out.println("7. Logout");
                            System.out.print("Select an option: ");

                            int userChoice = scanner.nextInt();
                            scanner.nextLine(); // Consume newline

                            switch (userChoice) {
                                case 1:
                                    System.out.print("enter item id : ");
                                    int itm = scanner.nextInt();
                                    String sql = "select * from Food_items where Food_id=?";
                                    PreparedStatement pst = connection.prepareStatement(sql);
                                    pst.setInt(1, itm);
                                    ResultSet rs = pst.executeQuery();
                                    try {
                                        if (rs.next() == false) {
                                            throw new unavailableItemId();
                                        } else if(!rs.getBoolean("Available")){
                                            System.out.println("item is not available at this time !");
                                        }else{
                                            System.out.println("enter quantity:");
                                            int quantity=scanner.nextInt();
                                            system.addItemToCart(itm,quantity , rs.getDouble("Price"), connection);
                                        }

                                    } catch (unavailableItemId e) {
                                        System.out.println("item id not available");
                                    }
                                    break;

                                case 2:
                                    system.viewCart();
                                    break;

                                case 3:
                                    system.removeItemFromCart();
                                    break;

                                case 4:
                                    system.emptyCart();
                                    break;

                                case 5:
                                    system.placeOrder();
                                    break;

                                case 6:
                                    Statement stmt = connection.createStatement();

                                    String query = "SELECT * FROM food_items";
                                    ResultSet resultSet = stmt.executeQuery(query);

                                    while (resultSet.next()) {
                                        int id = resultSet.getInt(1);
                                        String name = resultSet.getString(2);
                                        String category = resultSet.getString(3);
                                        double price = resultSet.getDouble(4);
                                        boolean available = resultSet.getBoolean(5);
                                        System.out.println("id : " + id);
                                        System.out.println("name : " + name);
                                        System.out.println("category : " + category);
                                        System.out.println("price : " + price);
                                        System.out.println("availability : " + available);
                                        System.out.println("--------------------------------------------- \n");
                                    }
                                    break;
                                case 7:
                                    userRunning = false;
                                    System.exit(0);
                                    break;

                                default:
                                    System.out.println("Invalid option. Please try again.");
                            }
                        }
                        break;

                    case 3:
                        system.exit();
                        running = false;
                        break;

                    default:
                        System.out.println("Invalid option. Please try again.");
                }
            }
            scanner.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}

class Payment {
    static Scanner sc = new Scanner(System.in);

    void payment_details(Connection connection, int id, String p_Method, double amount) throws SQLException {
        PreparedStatement pst = connection
                .prepareStatement("insert into payment(Order_id,payment_method,amount) values(?,?,?)");
        pst.setInt(1, id);
        pst.setString(2, p_Method);
        pst.setDouble(3, amount);
        pst.executeUpdate();
    }
}

class unavailableItemId extends Exception {
    unavailableItemId() {
        super();
    }
}